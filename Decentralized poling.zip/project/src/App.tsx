import React, { useState } from 'react';
import { Plus } from 'lucide-react';
import { WalletConnect } from './components/WalletConnect';
import { PollCard } from './components/PollCard';
import { CreatePollModal } from './components/CreatePollModal';
import { useWallet } from './hooks/useWallet';
import type { Poll } from './types';

const MOCK_POLLS: Poll[] = [
  {
    id: '1',
    title: 'Should we integrate more DeFi features?',
    description: 'Vote on whether we should expand our DeFi capabilities in the next quarter.',
    options: [
      { id: '1a', text: 'Yes, prioritize DeFi', votes: 150 },
      { id: '1b', text: 'No, focus on current features', votes: 75 },
    ],
    endDate: new Date('2024-04-01'),
    totalVotes: 225,
    burnedTokens: 500,
  },
  {
    id: '2',
    title: 'Community Governance Structure',
    description: 'Help decide the future of our governance model.',
    options: [
      { id: '2a', text: 'Delegated voting', votes: 300 },
      { id: '2b', text: 'Direct democracy', votes: 200 },
      { id: '2c', text: 'Hybrid model', votes: 100 },
    ],
    endDate: new Date('2024-03-25'),
    totalVotes: 600,
    burnedTokens: 1200,
  },
];

function App() {
  const { connected, address, connectWallet } = useWallet();
  const [polls, setPolls] = useState<Poll[]>(MOCK_POLLS);
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  const handleVote = (pollId: string, optionId: string) => {
    if (!connected) {
      alert('Please connect your wallet to vote');
      return;
    }

    setPolls((currentPolls) =>
      currentPolls.map((poll) => {
        if (poll.id === pollId) {
          return {
            ...poll,
            options: poll.options.map((option) => ({
              ...option,
              votes: option.id === optionId ? option.votes + 1 : option.votes,
            })),
            totalVotes: poll.totalVotes + 1,
          };
        }
        return poll;
      })
    );
  };

  const handleBurnTokens = (pollId: string) => {
    if (!connected) {
      alert('Please connect your wallet to burn tokens');
      return;
    }

    setPolls((currentPolls) =>
      currentPolls.map((poll) => {
        if (poll.id === pollId) {
          return {
            ...poll,
            burnedTokens: poll.burnedTokens + 100,
          };
        }
        return poll;
      })
    );
  };

  const handleCreatePoll = ({ title, description, options }: { title: string; description: string; options: string[] }) => {
    const newPoll: Poll = {
      id: String(polls.length + 1),
      title,
      description,
      options: options.map((text, index) => ({
        id: `${polls.length + 1}${String.fromCharCode(97 + index)}`,
        text,
        votes: 0,
      })),
      endDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days from now
      totalVotes: 0,
      burnedTokens: 0,
    };

    setPolls((currentPolls) => [...currentPolls, newPoll]);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold text-gray-900">Decentralized Polling</h1>
            <WalletConnect
              isConnected={connected}
              onConnect={connectWallet}
              walletAddress={address}
            />
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-xl font-semibold text-gray-800">Active Polls</h2>
          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="flex items-center gap-2 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors"
          >
            <Plus size={20} />
            Create Poll
          </button>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {polls.map((poll) => (
            <PollCard
              key={poll.id}
              poll={poll}
              onVote={handleVote}
              onBurnTokens={handleBurnTokens}
            />
          ))}
        </div>

        <CreatePollModal
          isOpen={isCreateModalOpen}
          onClose={() => setIsCreateModalOpen(false)}
          onSubmit={handleCreatePoll}
        />
      </main>
    </div>
  );
}

export default App;