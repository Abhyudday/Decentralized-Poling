export interface Poll {
  id: string;
  title: string;
  description: string;
  options: PollOption[];
  endDate: Date;
  totalVotes: number;
  burnedTokens: number;
}

export interface PollOption {
  id: string;
  text: string;
  votes: number;
}

export interface WalletState {
  connected: boolean;
  address: string | null;
  balance: {
    sol: number;
    send: number;
  };
}