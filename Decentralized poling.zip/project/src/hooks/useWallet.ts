import { useState, useCallback } from 'react';
import type { WalletState } from '../types';

export function useWallet() {
  const [walletState, setWalletState] = useState<WalletState>({
    connected: false,
    address: null,
    balance: {
      sol: 0,
      send: 0,
    },
  });

  const connectWallet = useCallback(() => {
    // Simulate wallet connection
    setWalletState({
      connected: true,
      address: '11111111111111111111111111111111',
      balance: {
        sol: 1.5,
        send: 1000,
      },
    });
  }, []);

  const disconnectWallet = useCallback(() => {
    setWalletState({
      connected: false,
      address: null,
      balance: {
        sol: 0,
        send: 0,
      },
    });
  }, []);

  return {
    ...walletState,
    connectWallet,
    disconnectWallet,
  };
}