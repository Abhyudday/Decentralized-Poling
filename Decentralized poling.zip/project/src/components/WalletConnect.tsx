import React from 'react';
import { Wallet } from 'lucide-react';

interface WalletConnectProps {
  isConnected: boolean;
  onConnect: () => void;
  walletAddress?: string;
}

export function WalletConnect({ isConnected, onConnect, walletAddress }: WalletConnectProps) {
  return (
    <div className="flex items-center gap-4">
      {isConnected ? (
        <div className="flex items-center gap-2 bg-green-100 text-green-800 px-4 py-2 rounded-lg">
          <Wallet size={20} />
          <span className="font-medium">
            {walletAddress?.slice(0, 4)}...{walletAddress?.slice(-4)}
          </span>
        </div>
      ) : (
        <button
          onClick={onConnect}
          className="flex items-center gap-2 bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700 transition-colors"
        >
          <Wallet size={20} />
          Connect Wallet
        </button>
      )}
    </div>
  );
}