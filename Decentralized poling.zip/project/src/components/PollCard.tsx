import React, { useState } from 'react';
import { BarChart, Flame } from 'lucide-react';
import type { Poll } from '../types';
import { VoteConfirmationModal } from './VoteConfirmationModal';
import { ThankYouModal } from './ThankYouModal';

interface PollCardProps {
  poll: Poll;
  onVote: (pollId: string, optionId: string) => void;
  onBurnTokens: (pollId: string) => void;
}

export function PollCard({ poll, onVote, onBurnTokens }: PollCardProps) {
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [showThankYou, setShowThankYou] = useState(false);

  const handleOptionSelect = (optionId: string) => {
    setSelectedOption(optionId);
  };

  const handleBurnAndVote = () => {
    if (!selectedOption) {
      alert('Please select an option first');
      return;
    }
    setShowConfirmation(true);
  };

  const handleConfirmVote = () => {
    if (selectedOption) {
      onVote(poll.id, selectedOption);
      onBurnTokens(poll.id);
      setShowConfirmation(false);
      setTimeout(() => {
        setShowThankYou(true);
        setSelectedOption(null);
      }, 300);
    }
  };

  const handleCloseThankYou = () => {
    setShowThankYou(false);
  };

  return (
    <div className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <h3 className="text-xl font-semibold text-gray-800">{poll.title}</h3>
        <div className="flex items-center gap-2 text-purple-600">
          <Flame size={20} />
          <span>{poll.burnedTokens} SEND</span>
        </div>
      </div>
      
      <p className="text-gray-600 mb-6">{poll.description}</p>
      
      <div className="space-y-3">
        {poll.options.map((option) => (
          <div key={option.id} className="relative">
            <button
              onClick={() => handleOptionSelect(option.id)}
              className={`w-full text-left p-3 rounded-lg border transition-colors ${
                selectedOption === option.id
                  ? 'border-purple-500 bg-purple-50'
                  : 'border-gray-200 hover:border-purple-300 hover:bg-purple-50'
              }`}
            >
              <div className="flex justify-between items-center">
                <span>{option.text}</span>
                <span className="text-gray-500 text-sm">
                  {((option.votes / (poll.totalVotes || 1)) * 100).toFixed(1)}%
                </span>
              </div>
              <div className="mt-2 h-2 bg-gray-100 rounded-full overflow-hidden">
                <div
                  className="h-full bg-purple-600 transition-all"
                  style={{
                    width: `${(option.votes / (poll.totalVotes || 1)) * 100}%`,
                  }}
                />
              </div>
            </button>
          </div>
        ))}
      </div>

      <div className="mt-6 flex justify-between items-center">
        <div className="flex items-center gap-2 text-gray-600">
          <BarChart size={20} />
          <span>{poll.totalVotes} votes</span>
        </div>
        <button
          onClick={handleBurnAndVote}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
            selectedOption
              ? 'bg-red-600 text-white hover:bg-red-700'
              : 'bg-red-100 text-red-600 hover:bg-red-200'
          }`}
        >
          <Flame size={18} />
          BURN SEND to Vote
        </button>
      </div>

      <VoteConfirmationModal
        isOpen={showConfirmation}
        onClose={() => setShowConfirmation(false)}
        onConfirm={handleConfirmVote}
        selectedOption={poll.options.find(opt => opt.id === selectedOption)?.text || ''}
        burnAmount={100}
      />

      <ThankYouModal
        isOpen={showThankYou}
        onClose={handleCloseThankYou}
      />
    </div>
  );
}