import React from 'react';
import { X, AlertCircle } from 'lucide-react';

interface VoteConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  selectedOption: string;
  burnAmount: number;
}

export function VoteConfirmationModal({
  isOpen,
  onClose,
  onConfirm,
  selectedOption,
  burnAmount,
}: VoteConfirmationModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-xl max-w-md w-full p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold">Confirm Your Vote</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X size={24} />
          </button>
        </div>

        <div className="mb-6">
          <p className="text-gray-700 mb-4">
            You are voting for: <span className="font-semibold">{selectedOption}</span>
          </p>
          <p className="text-gray-700 mb-4">
            Burning amount: <span className="font-semibold">{burnAmount} SEND</span>
          </p>
          
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3">
            <AlertCircle className="text-blue-500 mt-0.5" size={20} />
            <div className="text-sm text-blue-700">
              <p className="font-medium mb-1">Demo Website Notice</p>
              <p>This is a demonstration website. No actual tokens will be burned or transactions will be processed. This interface showcases the functionality of a decentralized polling system.</p>
            </div>
          </div>
        </div>

        <div className="flex justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-lg"
          >
            Cancel
          </button>
          <button
            onClick={() => {
              onConfirm();
              onClose();
            }}
            className="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
          >
            Confirm Vote
          </button>
        </div>
      </div>
    </div>
  );
}